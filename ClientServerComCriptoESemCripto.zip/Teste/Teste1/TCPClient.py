#!/usr/bin/python
# -*- coding: utf-8 -*-
from socket import *
serverName = '172.22.13.35'
serverPort = 12000

while 1:
	clientSocket = socket(AF_INET, SOCK_STREAM)
	clientSocket.connect((serverName,serverPort))
	message = raw_input(" Você :\n");
	clientSocket.sendto(message, (serverName,serverPort))
	modifiedMessage= clientSocket.recv (1024)
	print ("\n Server \n")
	print modifiedMessage
	clientSocket.close()

