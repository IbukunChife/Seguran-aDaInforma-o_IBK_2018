#!/usr/bin/python
# -*- coding: utf-8 -*-
from socket import *
serverPort = 12000
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('',serverPort))
serverSocket.listen(1)
print ("Server is ready");
while 1:
	connectionSocket, addr =serverSocket.accept()
	message= connectionSocket.recv (1024)	
	print ("Client : \n")	
	print (message)
	responce = raw_input(" \n Você : \n"); 
	connectionSocket.send (responce)	
	connectionSocket.close()

